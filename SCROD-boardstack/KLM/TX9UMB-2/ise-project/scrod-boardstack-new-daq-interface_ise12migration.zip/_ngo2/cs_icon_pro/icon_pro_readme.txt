The following files were generated for 'icon_pro' in directory
C:\Users\isar\Documents\code2\TX9UMB\ise-project\_ngo2\cs_icon_pro\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * icon_pro.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * icon_pro.ngc
   * icon_pro.vhd
   * icon_pro.vho

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * icon_pro.vho

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * icon_pro_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * icon_pro.gise
   * icon_pro.xise

Deliver Readme:
   Text file indicating the files generated and how they are used.

   * icon_pro_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * icon_pro_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

