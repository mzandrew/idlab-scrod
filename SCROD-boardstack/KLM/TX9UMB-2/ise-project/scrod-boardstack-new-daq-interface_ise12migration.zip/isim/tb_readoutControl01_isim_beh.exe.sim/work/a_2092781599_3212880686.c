/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x1cce1bb2 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/isar/Documents/code4/TX9UMB-2/src/DigitizingLgcTX.vhd";
extern char *IEEE_P_3620187407;

unsigned char ieee_p_3620187407_sub_1742983514_3965413181(char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_674691591_3965413181(char *, char *, char *, char *, unsigned char );


static void work_a_2092781599_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(83, ng0);

LAB3:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 6808);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 6648);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2092781599_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(84, ng0);

LAB3:    t1 = (t0 + 2632U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 6872);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 6664);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2092781599_3212880686_p_2(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(85, ng0);

LAB3:    t1 = (t0 + 2792U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 6936);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 6680);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2092781599_3212880686_p_3(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(86, ng0);

LAB3:    t1 = (t0 + 2952U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 7000);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 6696);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2092781599_3212880686_p_4(char *t0)
{
    char *t1;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(90, ng0);

LAB3:    t1 = (t0 + 11224);
    t3 = (t0 + 7064);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 13U);
    xsi_driver_first_trans_fast(t3);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2092781599_3212880686_p_5(char *t0)
{
    char *t1;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(92, ng0);

LAB3:    t1 = (t0 + 11237);
    t3 = (t0 + 7128);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 13U);
    xsi_driver_first_trans_fast(t3);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2092781599_3212880686_p_6(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(97, ng0);
    t2 = (t0 + 992U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 6712);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(98, ng0);
    t4 = (t0 + 1352U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (t0 + 7192);
    t10 = (t4 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = t9;
    xsi_driver_first_trans_fast(t4);
    goto LAB3;

LAB5:    t4 = (t0 + 1032U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

}

static void work_a_2092781599_3212880686_p_7(char *t0)
{
    char t18[16];
    char t21[16];
    char t31[16];
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    int t19;
    unsigned int t20;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    unsigned int t28;
    int t29;
    unsigned int t30;
    unsigned int t32;
    char *t33;
    static char *nl0[] = {&&LAB9, &&LAB10, &&LAB11, &&LAB12, &&LAB13, &&LAB14};

LAB0:    xsi_set_current_line(104, ng0);
    t2 = (t0 + 992U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 6728);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(106, ng0);
    t4 = (t0 + 2312U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t4 = (char *)((nl0) + t9);
    goto **((char **)t4);

LAB5:    t4 = (t0 + 1032U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    goto LAB3;

LAB9:    xsi_set_current_line(108, ng0);
    t10 = (t0 + 7256);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast(t10);
    xsi_set_current_line(109, ng0);
    t2 = (t0 + 7320);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(110, ng0);
    t2 = (t0 + 7384);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(111, ng0);
    t2 = xsi_get_transient_memory(13U);
    memset(t2, 0, 13U);
    t4 = t2;
    memset(t4, (unsigned char)2, 13U);
    t5 = (t0 + 7448);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 13U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(112, ng0);
    t2 = (t0 + 7512);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(113, ng0);
    t2 = (t0 + 2152U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)3);
    if (t3 != 0)
        goto LAB15;

LAB17:    xsi_set_current_line(116, ng0);
    t2 = (t0 + 7576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);

LAB16:    goto LAB8;

LAB10:    xsi_set_current_line(120, ng0);
    t2 = (t0 + 7256);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(121, ng0);
    t2 = (t0 + 7320);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(122, ng0);
    t2 = (t0 + 7384);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(123, ng0);
    t2 = (t0 + 7512);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(124, ng0);
    t2 = (t0 + 3432U);
    t4 = *((char **)t2);
    t15 = (12 - 12);
    t16 = (t15 * 1U);
    t17 = (0 + t16);
    t2 = (t4 + t17);
    t5 = (t18 + 0U);
    t8 = (t5 + 0U);
    *((int *)t8) = 12;
    t8 = (t5 + 4U);
    *((int *)t8) = 0;
    t8 = (t5 + 8U);
    *((int *)t8) = -1;
    t19 = (0 - 12);
    t20 = (t19 * -1);
    t20 = (t20 + 1);
    t8 = (t5 + 12U);
    *((unsigned int *)t8) = t20;
    t8 = (t0 + 3112U);
    t10 = *((char **)t8);
    t8 = (t0 + 11108U);
    t1 = ieee_p_3620187407_sub_1742983514_3965413181(IEEE_P_3620187407, t2, t18, t10, t8);
    if (t1 != 0)
        goto LAB18;

LAB20:    xsi_set_current_line(128, ng0);
    t2 = xsi_get_transient_memory(13U);
    memset(t2, 0, 13U);
    t4 = t2;
    memset(t4, (unsigned char)2, 13U);
    t5 = (t0 + 7448);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 13U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(129, ng0);
    t2 = (t0 + 7576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);

LAB19:    goto LAB8;

LAB11:    xsi_set_current_line(133, ng0);
    t2 = (t0 + 7256);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(134, ng0);
    t2 = (t0 + 7320);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(135, ng0);
    t2 = (t0 + 7384);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(136, ng0);
    t2 = (t0 + 3432U);
    t4 = *((char **)t2);
    t15 = (12 - 12);
    t16 = (t15 * 1U);
    t17 = (0 + t16);
    t2 = (t4 + t17);
    t5 = (t18 + 0U);
    t8 = (t5 + 0U);
    *((int *)t8) = 12;
    t8 = (t5 + 4U);
    *((int *)t8) = 0;
    t8 = (t5 + 8U);
    *((int *)t8) = -1;
    t19 = (0 - 12);
    t20 = (t19 * -1);
    t20 = (t20 + 1);
    t8 = (t5 + 12U);
    *((unsigned int *)t8) = t20;
    t8 = (t0 + 3272U);
    t10 = *((char **)t8);
    t8 = (t0 + 11124U);
    t1 = ieee_p_3620187407_sub_1742983514_3965413181(IEEE_P_3620187407, t2, t18, t10, t8);
    if (t1 != 0)
        goto LAB23;

LAB25:    xsi_set_current_line(140, ng0);
    t2 = xsi_get_transient_memory(13U);
    memset(t2, 0, 13U);
    t4 = t2;
    memset(t4, (unsigned char)2, 13U);
    t5 = (t0 + 7448);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 13U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(141, ng0);
    t2 = (t0 + 7576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);

LAB24:    goto LAB8;

LAB12:    xsi_set_current_line(145, ng0);
    t2 = (t0 + 7256);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(146, ng0);
    t2 = (t0 + 7320);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(147, ng0);
    t2 = (t0 + 7384);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(148, ng0);
    t2 = (t0 + 3432U);
    t4 = *((char **)t2);
    t15 = (12 - 12);
    t16 = (t15 * 1U);
    t17 = (0 + t16);
    t2 = (t4 + t17);
    t5 = (t18 + 0U);
    t8 = (t5 + 0U);
    *((int *)t8) = 12;
    t8 = (t5 + 4U);
    *((int *)t8) = 0;
    t8 = (t5 + 8U);
    *((int *)t8) = -1;
    t19 = (0 - 12);
    t20 = (t19 * -1);
    t20 = (t20 + 1);
    t8 = (t5 + 12U);
    *((unsigned int *)t8) = t20;
    t8 = (t0 + 1512U);
    t10 = *((char **)t8);
    t20 = (12 - 12);
    t22 = (t20 * 1U);
    t28 = (0 + t22);
    t8 = (t10 + t28);
    t11 = (t21 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 12;
    t12 = (t11 + 4U);
    *((int *)t12) = 0;
    t12 = (t11 + 8U);
    *((int *)t12) = -1;
    t29 = (0 - 12);
    t30 = (t29 * -1);
    t30 = (t30 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t30;
    t1 = ieee_p_3620187407_sub_1742983514_3965413181(IEEE_P_3620187407, t2, t18, t8, t21);
    if (t1 != 0)
        goto LAB28;

LAB30:    xsi_set_current_line(152, ng0);
    t2 = xsi_get_transient_memory(13U);
    memset(t2, 0, 13U);
    t4 = t2;
    memset(t4, (unsigned char)2, 13U);
    t5 = (t0 + 7448);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 13U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(153, ng0);
    t2 = (t0 + 7576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)4;
    xsi_driver_first_trans_fast(t2);

LAB29:    goto LAB8;

LAB13:    xsi_set_current_line(157, ng0);
    t2 = (t0 + 7256);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(158, ng0);
    t2 = (t0 + 7320);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(159, ng0);
    t2 = (t0 + 7384);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(160, ng0);
    t2 = xsi_get_transient_memory(13U);
    memset(t2, 0, 13U);
    t4 = t2;
    memset(t4, (unsigned char)2, 13U);
    t5 = (t0 + 7448);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 13U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(161, ng0);
    t2 = (t0 + 7512);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(162, ng0);
    t2 = (t0 + 2152U);
    t4 = *((char **)t2);
    t1 = *((unsigned char *)t4);
    t3 = (t1 == (unsigned char)2);
    if (t3 != 0)
        goto LAB33;

LAB35:    xsi_set_current_line(165, ng0);
    t2 = (t0 + 7576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)4;
    xsi_driver_first_trans_fast(t2);

LAB34:    goto LAB8;

LAB14:    xsi_set_current_line(169, ng0);
    t2 = (t0 + 7256);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(170, ng0);
    t2 = (t0 + 7384);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(171, ng0);
    t2 = (t0 + 7320);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(172, ng0);
    t2 = xsi_get_transient_memory(13U);
    memset(t2, 0, 13U);
    t4 = t2;
    memset(t4, (unsigned char)2, 13U);
    t5 = (t0 + 7448);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 13U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(173, ng0);
    t2 = (t0 + 7576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    goto LAB8;

LAB15:    xsi_set_current_line(114, ng0);
    t2 = (t0 + 7576);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)1;
    xsi_driver_first_trans_fast(t2);
    goto LAB16;

LAB18:    xsi_set_current_line(125, ng0);
    t11 = (t0 + 3432U);
    t12 = *((char **)t11);
    t11 = (t0 + 11140U);
    t13 = ieee_p_3620187407_sub_674691591_3965413181(IEEE_P_3620187407, t21, t12, t11, (unsigned char)3);
    t14 = (t21 + 12U);
    t20 = *((unsigned int *)t14);
    t22 = (1U * t20);
    t3 = (13U != t22);
    if (t3 == 1)
        goto LAB21;

LAB22:    t23 = (t0 + 7448);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    memcpy(t27, t13, 13U);
    xsi_driver_first_trans_fast(t23);
    xsi_set_current_line(126, ng0);
    t2 = (t0 + 7576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)1;
    xsi_driver_first_trans_fast(t2);
    goto LAB19;

LAB21:    xsi_size_not_matching(13U, t22, 0);
    goto LAB22;

LAB23:    xsi_set_current_line(137, ng0);
    t11 = (t0 + 3432U);
    t12 = *((char **)t11);
    t11 = (t0 + 11140U);
    t13 = ieee_p_3620187407_sub_674691591_3965413181(IEEE_P_3620187407, t21, t12, t11, (unsigned char)3);
    t14 = (t21 + 12U);
    t20 = *((unsigned int *)t14);
    t22 = (1U * t20);
    t3 = (13U != t22);
    if (t3 == 1)
        goto LAB26;

LAB27:    t23 = (t0 + 7448);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    memcpy(t27, t13, 13U);
    xsi_driver_first_trans_fast(t23);
    xsi_set_current_line(138, ng0);
    t2 = (t0 + 7576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    goto LAB24;

LAB26:    xsi_size_not_matching(13U, t22, 0);
    goto LAB27;

LAB28:    xsi_set_current_line(149, ng0);
    t12 = (t0 + 3432U);
    t13 = *((char **)t12);
    t12 = (t0 + 11140U);
    t14 = ieee_p_3620187407_sub_674691591_3965413181(IEEE_P_3620187407, t31, t13, t12, (unsigned char)3);
    t23 = (t31 + 12U);
    t30 = *((unsigned int *)t23);
    t32 = (1U * t30);
    t3 = (13U != t32);
    if (t3 == 1)
        goto LAB31;

LAB32:    t24 = (t0 + 7448);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t33 = *((char **)t27);
    memcpy(t33, t14, 13U);
    xsi_driver_first_trans_fast(t24);
    xsi_set_current_line(150, ng0);
    t2 = (t0 + 7576);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB29;

LAB31:    xsi_size_not_matching(13U, t32, 0);
    goto LAB32;

LAB33:    xsi_set_current_line(163, ng0);
    t2 = (t0 + 7576);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    goto LAB34;

}


extern void work_a_2092781599_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2092781599_3212880686_p_0,(void *)work_a_2092781599_3212880686_p_1,(void *)work_a_2092781599_3212880686_p_2,(void *)work_a_2092781599_3212880686_p_3,(void *)work_a_2092781599_3212880686_p_4,(void *)work_a_2092781599_3212880686_p_5,(void *)work_a_2092781599_3212880686_p_6,(void *)work_a_2092781599_3212880686_p_7};
	xsi_register_didat("work_a_2092781599_3212880686", "isim/tb_readoutControl01_isim_beh.exe.sim/work/a_2092781599_3212880686.didat");
	xsi_register_executes(pe);
}
