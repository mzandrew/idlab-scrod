/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x1cce1bb2 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/isar/Documents/code4/TX9UMB-2/src/SamplingLgc.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;

int ieee_p_1242562249_sub_1657552908_1035706684(char *, char *, char *);
unsigned char ieee_p_1242562249_sub_1781471956_1035706684(char *, char *, char *, int );
unsigned char ieee_p_1242562249_sub_1781543830_1035706684(char *, char *, char *, int );
char *ieee_p_1242562249_sub_180853171_1035706684(char *, char *, int , int );
char *ieee_p_1242562249_sub_1919365254_1035706684(char *, char *, char *, char *, int );
unsigned char ieee_p_2592010699_sub_1690584930_503743352(char *, unsigned char );
unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_2929259731_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(73, ng0);

LAB3:    t1 = (t0 + 2952U);
    t2 = *((char **)t1);
    t3 = (8 - 8);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 8016);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 9U);
    xsi_driver_first_trans_fast_port(t6);

LAB2:    t11 = (t0 + 7840);
    *((int *)t11) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2929259731_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(74, ng0);

LAB3:    t1 = (t0 + 3112U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 8080);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 7856);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2929259731_3212880686_p_2(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(75, ng0);

LAB3:    t1 = (t0 + 3272U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 8144);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 7872);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2929259731_3212880686_p_3(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(76, ng0);

LAB3:    t1 = (t0 + 3432U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 8208);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 7888);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2929259731_3212880686_p_4(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(77, ng0);

LAB3:    t1 = (t0 + 3432U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 8272);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 7904);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2929259731_3212880686_p_5(char *t0)
{
    char t13[16];
    char t21[16];
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    int t10;
    int t11;
    int t12;
    int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    char *t20;
    unsigned int t22;

LAB0:    xsi_set_current_line(82, ng0);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 7920);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(83, ng0);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t3 = (t0 + 8336);
    t6 = (t3 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t5;
    xsi_driver_first_trans_fast(t3);
    xsi_set_current_line(84, ng0);
    t1 = (t0 + 1352U);
    t3 = *((char **)t1);
    t1 = (t0 + 13012U);
    t10 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t3, t1);
    t4 = (t0 + 8400);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((int *)t9) = t10;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(85, ng0);
    t1 = (t0 + 1512U);
    t3 = *((char **)t1);
    t1 = (t0 + 13028U);
    t10 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t3, t1);
    t4 = (t0 + 8464);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((int *)t9) = t10;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(86, ng0);
    t1 = (t0 + 4072U);
    t3 = *((char **)t1);
    t10 = *((int *)t3);
    t1 = (t0 + 4232U);
    t4 = *((char **)t1);
    t11 = *((int *)t4);
    t12 = (t10 + t11);
    t1 = (t0 + 8528);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((int *)t9) = t12;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(87, ng0);
    t1 = (t0 + 4392U);
    t3 = *((char **)t1);
    t10 = *((int *)t3);
    t1 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t13, t10, 10);
    t4 = (t13 + 0U);
    t11 = *((int *)t4);
    t6 = (t13 + 8U);
    t12 = *((int *)t6);
    t14 = (9 - t11);
    t15 = (t14 * t12);
    t16 = (1U * t15);
    t17 = (0 + t16);
    t7 = (t1 + t17);
    t2 = *((unsigned char *)t7);
    t8 = (t0 + 8592);
    t9 = (t8 + 56U);
    t18 = *((char **)t9);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = t2;
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(88, ng0);
    t1 = (t0 + 4392U);
    t3 = *((char **)t1);
    t10 = *((int *)t3);
    t1 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t13, t10, 10);
    t4 = (t13 + 0U);
    t11 = *((int *)t4);
    t15 = (t11 - 8);
    t16 = (t15 * 1U);
    t17 = (0 + t16);
    t6 = (t1 + t17);
    t7 = (t21 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 8;
    t8 = (t7 + 4U);
    *((int *)t8) = 0;
    t8 = (t7 + 8U);
    *((int *)t8) = -1;
    t12 = (0 - 8);
    t22 = (t12 * -1);
    t22 = (t22 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t22;
    t14 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t6, t21);
    t8 = (t0 + 8656);
    t9 = (t8 + 56U);
    t18 = *((char **)t9);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((int *)t20) = t14;
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(89, ng0);
    t1 = (t0 + 1672U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t1 = (t0 + 8720);
    t4 = (t1 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t2;
    xsi_driver_first_trans_fast(t1);
    goto LAB3;

}

static void work_a_2929259731_3212880686_p_6(char *t0)
{
    char t3[16];
    char *t1;
    unsigned char t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned char t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    unsigned char t20;
    int t21;
    unsigned char t22;
    unsigned char t23;
    unsigned char t24;
    unsigned char t25;
    unsigned char t26;
    char *t27;
    char *t28;
    char *t29;
    int t30;
    unsigned char t31;
    char *t32;
    char *t33;
    char *t34;
    int t35;
    unsigned char t36;
    char *t37;
    unsigned char t38;
    unsigned char t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    unsigned int t44;
    static char *nl0[] = {&&LAB27, &&LAB28, &&LAB29};

LAB0:    xsi_set_current_line(95, ng0);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 7936);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(96, ng0);
    t4 = (t0 + 3592U);
    t5 = *((char **)t4);
    t4 = (t0 + 13076U);
    t6 = ieee_p_1242562249_sub_1919365254_1035706684(IEEE_P_1242562249, t3, t5, t4, 1);
    t7 = (t0 + 8784);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t6, 2U);
    xsi_driver_first_trans_fast(t7);
    xsi_set_current_line(97, ng0);
    t1 = (t0 + 3592U);
    t4 = *((char **)t1);
    t12 = (1 - 1);
    t13 = (t12 * -1);
    t14 = (1U * t13);
    t15 = (0 + t14);
    t1 = (t4 + t15);
    t2 = *((unsigned char *)t1);
    t5 = (t0 + 8848);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t2;
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(99, ng0);
    t1 = (t0 + 3912U);
    t4 = *((char **)t1);
    t2 = *((unsigned char *)t4);
    t16 = (t2 == (unsigned char)3);
    if (t16 != 0)
        goto LAB5;

LAB7:
LAB6:    xsi_set_current_line(103, ng0);
    t1 = (t0 + 4712U);
    t4 = *((char **)t1);
    t17 = *((unsigned char *)t4);
    t18 = (t17 == (unsigned char)2);
    if (t18 == 1)
        goto LAB14;

LAB15:    t16 = (unsigned char)0;

LAB16:    if (t16 == 1)
        goto LAB11;

LAB12:    t9 = (t0 + 4712U);
    t11 = *((char **)t9);
    t24 = *((unsigned char *)t11);
    t25 = (t24 == (unsigned char)3);
    if (t25 == 1)
        goto LAB20;

LAB21:    t23 = (unsigned char)0;

LAB22:    t2 = t23;

LAB13:    if (t2 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(109, ng0);
    t1 = (t0 + 8976);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);

LAB9:    xsi_set_current_line(114, ng0);
    t1 = (t0 + 2632U);
    t4 = *((char **)t1);
    t2 = *((unsigned char *)t4);
    t1 = (char *)((nl0) + t2);
    goto **((char **)t1);

LAB5:    xsi_set_current_line(100, ng0);
    t1 = (t0 + 8912);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB6;

LAB8:    xsi_set_current_line(106, ng0);
    t33 = (t0 + 1672U);
    t37 = *((char **)t33);
    t38 = *((unsigned char *)t37);
    t39 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t38);
    t33 = (t0 + 8976);
    t40 = (t33 + 56U);
    t41 = *((char **)t40);
    t42 = (t41 + 56U);
    t43 = *((char **)t42);
    *((unsigned char *)t43) = t39;
    xsi_driver_first_trans_fast(t33);
    goto LAB9;

LAB11:    t2 = (unsigned char)1;
    goto LAB13;

LAB14:    t1 = (t0 + 2952U);
    t5 = *((char **)t1);
    t1 = (t0 + 13060U);
    t6 = (t0 + 4072U);
    t7 = *((char **)t6);
    t12 = *((int *)t7);
    t20 = ieee_p_1242562249_sub_1781543830_1035706684(IEEE_P_1242562249, t5, t1, t12);
    if (t20 == 1)
        goto LAB17;

LAB18:    t19 = (unsigned char)0;

LAB19:    t16 = t19;
    goto LAB16;

LAB17:    t6 = (t0 + 2952U);
    t8 = *((char **)t6);
    t6 = (t0 + 13060U);
    t9 = (t0 + 4872U);
    t10 = *((char **)t9);
    t21 = *((int *)t10);
    t22 = ieee_p_1242562249_sub_1781471956_1035706684(IEEE_P_1242562249, t8, t6, t21);
    t19 = t22;
    goto LAB19;

LAB20:    t9 = (t0 + 2952U);
    t27 = *((char **)t9);
    t9 = (t0 + 13060U);
    t28 = (t0 + 4072U);
    t29 = *((char **)t28);
    t30 = *((int *)t29);
    t31 = ieee_p_1242562249_sub_1781543830_1035706684(IEEE_P_1242562249, t27, t9, t30);
    if (t31 == 1)
        goto LAB23;

LAB24:    t28 = (t0 + 2952U);
    t32 = *((char **)t28);
    t28 = (t0 + 13060U);
    t33 = (t0 + 4872U);
    t34 = *((char **)t33);
    t35 = *((int *)t34);
    t36 = ieee_p_1242562249_sub_1781471956_1035706684(IEEE_P_1242562249, t32, t28, t35);
    t26 = t36;

LAB25:    t23 = t26;
    goto LAB22;

LAB23:    t26 = (unsigned char)1;
    goto LAB25;

LAB26:    goto LAB3;

LAB27:    xsi_set_current_line(119, ng0);
    t5 = (t0 + 9040);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)3;
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(120, ng0);
    t1 = (t0 + 3752U);
    t4 = *((char **)t1);
    t12 = *((int *)t4);
    t21 = (t12 + 1);
    t1 = (t0 + 9104);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((int *)t8) = t21;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(121, ng0);
    t1 = (t0 + 3752U);
    t4 = *((char **)t1);
    t12 = *((int *)t4);
    t2 = (t12 == 4);
    if (t2 != 0)
        goto LAB30;

LAB32:    xsi_set_current_line(128, ng0);
    t1 = (t0 + 8912);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);

LAB31:    goto LAB26;

LAB28:    xsi_set_current_line(134, ng0);
    t1 = (t0 + 3592U);
    t4 = *((char **)t1);
    t1 = (t0 + 13170);
    t16 = 1;
    if (2U == 2U)
        goto LAB39;

LAB40:    t16 = 0;

LAB41:    if (t16 == 1)
        goto LAB36;

LAB37:    t8 = (t0 + 3592U);
    t9 = *((char **)t8);
    t8 = (t0 + 13172);
    t17 = 1;
    if (2U == 2U)
        goto LAB45;

LAB46:    t17 = 0;

LAB47:    t2 = t17;

LAB38:    if (t2 != 0)
        goto LAB33;

LAB35:
LAB34:    goto LAB26;

LAB29:    xsi_set_current_line(139, ng0);
    t1 = xsi_get_transient_memory(9U);
    memset(t1, 0, 9U);
    t4 = t1;
    memset(t4, (unsigned char)2, 9U);
    t5 = (t0 + 9168);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 9U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(140, ng0);
    t1 = (t0 + 8912);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB26;

LAB30:    xsi_set_current_line(122, ng0);
    t1 = (t0 + 9104);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((int *)t8) = 0;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(123, ng0);
    t1 = (t0 + 13168);
    t5 = (t0 + 8784);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 2U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(124, ng0);
    t1 = (t0 + 9040);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(125, ng0);
    t1 = xsi_get_transient_memory(9U);
    memset(t1, 0, 9U);
    t4 = t1;
    memset(t4, (unsigned char)2, 9U);
    t5 = (t0 + 9168);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 9U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(126, ng0);
    t1 = (t0 + 8912);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)1;
    xsi_driver_first_trans_fast(t1);
    goto LAB31;

LAB33:    xsi_set_current_line(135, ng0);
    t28 = (t0 + 2952U);
    t29 = *((char **)t28);
    t28 = (t0 + 13060U);
    t32 = ieee_p_1242562249_sub_1919365254_1035706684(IEEE_P_1242562249, t3, t29, t28, 1);
    t33 = (t3 + 12U);
    t15 = *((unsigned int *)t33);
    t44 = (1U * t15);
    t18 = (9U != t44);
    if (t18 == 1)
        goto LAB51;

LAB52:    t34 = (t0 + 9168);
    t37 = (t34 + 56U);
    t40 = *((char **)t37);
    t41 = (t40 + 56U);
    t42 = *((char **)t41);
    memcpy(t42, t32, 9U);
    xsi_driver_first_trans_fast(t34);
    goto LAB34;

LAB36:    t2 = (unsigned char)1;
    goto LAB38;

LAB39:    t13 = 0;

LAB42:    if (t13 < 2U)
        goto LAB43;
    else
        goto LAB41;

LAB43:    t6 = (t4 + t13);
    t7 = (t1 + t13);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB40;

LAB44:    t13 = (t13 + 1);
    goto LAB42;

LAB45:    t14 = 0;

LAB48:    if (t14 < 2U)
        goto LAB49;
    else
        goto LAB47;

LAB49:    t11 = (t9 + t14);
    t27 = (t8 + t14);
    if (*((unsigned char *)t11) != *((unsigned char *)t27))
        goto LAB46;

LAB50:    t14 = (t14 + 1);
    goto LAB48;

LAB51:    xsi_size_not_matching(9U, t44, 0);
    goto LAB52;

}


extern void work_a_2929259731_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2929259731_3212880686_p_0,(void *)work_a_2929259731_3212880686_p_1,(void *)work_a_2929259731_3212880686_p_2,(void *)work_a_2929259731_3212880686_p_3,(void *)work_a_2929259731_3212880686_p_4,(void *)work_a_2929259731_3212880686_p_5,(void *)work_a_2929259731_3212880686_p_6};
	xsi_register_didat("work_a_2929259731_3212880686", "isim/tb_readoutControl01_isim_beh.exe.sim/work/a_2929259731_3212880686.didat");
	xsi_register_executes(pe);
}
